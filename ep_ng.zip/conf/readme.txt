Uporabniki (uporabnisko ime: geslo):
    admin: admin
    seller1: seller1
    seller2: seller2
    customer1: customer1
    customer2: customer2

Geslo za uvoz vseh certifikatov: ep
Certifikati so shranjeni v mapi conf/certs
